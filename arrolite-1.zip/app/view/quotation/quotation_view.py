from django.views import View
from django.shortcuts import get_object_or_404, render, redirect
from app.models.customer_model.customer_model import CustomUser, Customer
from app.models.invoice_model.invoice_model import Invoice
from app.models.iso_series.iso_series_model import ISOSize
from app.models.product.product_model import Product
from app.models.product.quotation_model import Quotation, QuotationItem
from app.models.unit.unit_model import Unit
from django.contrib import messages 
from django.http import JsonResponse
from datetime import datetime
from django.db import DatabaseError

class QuotationView(View):
    template = "pages/product/quotationitems.html"

    def get(self, request,pk):
        quotation = get_object_or_404(Quotation.active_objects, id=pk)
        quotation_items = QuotationItem.active_objects.filter(quotation=quotation)     
        context = {
            'quotation':quotation,
            'quotationsitems': quotation_items,
        }
        return render(request, self.template, context)
    
class QuotationApprovalView(View):
    template = "pages/quotation/quotation_approval_list.html"
    def get(self, request):
        quotation = Quotation.active_objects.all().order_by("-created_at")
     
        context = {
            'quotations':quotation,
        }
        
        return render(request, self.template, context)
 
class QuotationListView(View):
    template = "pages/quotation/quotation_list.html"

    def get(self, request):
        # if request.user.is_superuser:
        #     quotations = Quotation.active_objects.all().order_by('-created_at')
        # else :
        #     quotations = Quotation.active_objects.filter(approver = request.user).order_by('-created_at') 
        quotations = Quotation.active_objects.all().order_by('-created_at')     
        products = Product.active_objects.all()
        units = Unit.active_objects.all()
        customer = Customer.active_objects.all()
        context = {
            'quotations': quotations,
            'products': products,
            'units': units,
            'users': customer,
        }
 
        return render(request, self.template, context)
 
from django.db import transaction
    
class QuotationRequestView(View):
    template = "pages/quotation/quotation_form.html"
    def get(self, request):
        products = Product.active_objects.all()
        units = Unit.active_objects.all()
        customer = Customer.active_objects.all() 
        iso_sizes = ISOSize.active_objects.all()  
        context = { 
            'products': products,
            'units': units,
            'users': customer,
            "iso_sizes":iso_sizes
        } 
        return render(request, self.template, context)
    
    def post(self, request):
        requite_date = request.POST.get("requite_date")
        user_id = request.POST.get("user")
        description = request.POST.get("description")
        # iso_size = request.POST.get("iso_size")
        if not requite_date or not user_id:
            messages.error(request, "Request date and user are required.")
            return self.render_with_context(request)

        user = get_object_or_404(Customer.active_objects, id=user_id)
        # iso_size = get_object_or_404(ISOSize.active_objects, id=iso_size)
        items = self.extract_valid_items(request.POST)

        if not items:
            messages.error(request, "At least one product must be added to create a quotation.")
            return self.render_with_context(request)

        # ✅ Create quotation
        quotation = Quotation.objects.create(
            invoice_number=self.generate_quotation_number(),
            request_date=requite_date,
            approver_status ="pending",
            approver = self.request.user,
            description=description,
            # isosize = iso_size,
            customer=user
        
        )
        

        # ✅ Save valid items
        for item in items:
            QuotationItem.objects.create(quotation=quotation, **item) 
        messages.success(request, "Quotation created successfully.")
        return redirect('quotation_list')

    def generate_quotation_number(self):
        with transaction.atomic():
            last_quotation = Quotation.objects.select_for_update().order_by('-id').first()
            if last_quotation and last_quotation.invoice_number:
                last_number = int(last_quotation.invoice_number.replace('Q', ''))
                new_number = last_number + 1
            else:
                new_number = 1
            return f"Q{new_number:04d}"

    def extract_valid_items(self, post_data):
        items = []
        counter = 1
        while True:
            product_id = post_data.get(f'product_{counter}')
            if not product_id:
                break
            try:
                product = Product.objects.get(id=product_id)
                qty = float(post_data.get(f'qty_{counter}', 0))
                width = float(post_data.get(f'width_{counter}', 0) or 0)
                height = float(post_data.get(f'height_{counter}', 0) or 0)
                unit_cost = float(post_data.get(f'unit_cost_{counter}', 0) or 0)
                unit_id = post_data.get(f'unit_{counter}')    
                unit = Unit.active_objects.get(symbol=unit_id) if unit_id else None
                description = post_data.get(f'description_{counter}', '').strip()

                if qty > 0:
                    items.append({
                        'product': product,
                        'quantity': qty,
                        'width': width,
                        'height': height,
                        'unit_cost': unit_cost,
                        'unit': unit,
                        'description': description
                    })
            except (Product.DoesNotExist, Unit.DoesNotExist, ValueError):
                pass  # skip this row if anything is invalid

            counter += 1
        return items

    def render_with_context(self, request):
        quotations = Quotation.active_objects.all()
        products = Product.active_objects.all()
        units = Unit.active_objects.all()
        users = CustomUser.active_objects.all()
        context = {
            'quotations': quotations,
            'products': products,
            'units': units,
            'users': users
        }
        return render(request, self.template, context)
 
class QuotationApprove(View):
    template = "pages/quotation/quotation_approval_form.html"

    def get(self, request, pk):
        quotation = get_object_or_404(Quotation.active_objects, id=pk)
        quotation_items = QuotationItem.active_objects.filter(quotation=quotation)
        context = {
            'quotation': quotation,
            'quotationsitems': quotation_items,
        }
        return render(request, self.template, context) 
    def post(self, request, pk):
        quotation = get_object_or_404(Quotation, id=pk)
        discount = request.POST.get('discount')
        status = request.POST.get('status')

        if not status:
            messages.error(request, "Status is required.")
            return redirect(request.path)

        if discount:
            try:
                discount_value = float(discount)
                if not (0 <= discount_value <= 100):
                    messages.error(request, "Discount must be between 0 and 100.")
                    return redirect(request.path)
                quotation.discount = discount_value
            except ValueError:
                messages.error(request, "Invalid discount format.")
                return redirect(request.path)

        if request.user.has_perm("app.can_modify_discount_quotations"):
            quotation.approver_status = status
            quotation.save()
            messages.success(request, "Quotation updated successfully.")
            return redirect('quotation_waiting')

        messages.error(request, "You are not allowed to update this quotation.")
        return redirect(request.path)
    
class QuotationEditView(View):
    """
    Edit an existing Quotation.
    
    Key behaviours
    --------------
    * GET  – loads the quotation with its items pre-filled.
             The customer dropdown is locked to the quotation's own customer
             (only that one customer is passed to the template).
    * POST – validates header fields, re-extracts items using the same
             counter-based naming as QuotationRequestView, then replaces
             all QuotationItem rows atomically.
    """
    template = "pages/quotation/quotation_edit_form.html"

    # ------------------------------------------------------------------ GET --
    def get(self, request, pk):
        quotation = get_object_or_404(
            Quotation.objects.prefetch_related("items"),
            id=pk,
        )
        products      = Product.active_objects.all()
        units         = Unit.active_objects.all()
        existing_items = quotation.items.all()
        customer_list = Customer.active_objects.all() 

        context = {
            "quotation":      quotation,
            "products":       products,
            "units":          units,
            # ⚠️  Only the quotation's own customer — NOT all customers.
            #     The template renders a single locked <option>.
            "locked_customer": quotation.customer,
            "existing_items": existing_items,
            "customer_list": customer_list,
        }
        return render(request, self.template, context)

    # ----------------------------------------------------------------- POST --
    def post(self, request, pk):
        quotation = get_object_or_404(Quotation, id=pk)

        requite_date = request.POST.get("requite_date")
        description  = request.POST.get("description")
        customer  = request.POST.get("customer_id")
        if  customer:
            quotation.customer = Customer.objects.get(id=customer)

        if not requite_date:
            messages.error(request, "Request date is required.")
            return self._render_with_context(request, quotation)

        items = self._extract_valid_items(request.POST)

        if not items:
            messages.error(request, "At least one product must be added.")
            return self._render_with_context(request, quotation)

        # ✅ Update quotation header fields.
        #    Customer is NOT changed on edit (locked to original).
        quotation.request_date = requite_date
        quotation.description  = description
        quotation.save()

        # ✅ Replace all items atomically: delete old → insert new.
        with transaction.atomic():
            quotation.items.all().delete()
            for item in items:
                QuotationItem.objects.create(quotation=quotation, **item)

        messages.success(request, "Quotation updated successfully.")
        return redirect("quotation_list")

    # -------------------------------------------------------- helpers --------
    def _extract_valid_items(self, post_data):
        """
        Identical extraction logic to QuotationRequestView.extract_valid_items.
        Reads product_1/qty_1/width_1/height_1/unit_1/unit_cost_1/description_1
        and increments until no product_N key is found.
        """
        items   = []
        counter = 1
        while True:
            product_id = post_data.get(f"product_{counter}")
            if not product_id:
                break
            try:
                product   = Product.objects.get(id=product_id)
                qty       = float(post_data.get(f"qty_{counter}",       0))
                width     = float(post_data.get(f"width_{counter}",     0) or 0)
                height    = float(post_data.get(f"height_{counter}",    0) or 0)
                unit_cost = float(post_data.get(f"unit_cost_{counter}", 0) or 0)
                unit_id   = post_data.get(f"unit_{counter}")
                unit      = Unit.active_objects.get(symbol=unit_id) if unit_id else None
                description = post_data.get(f"description_{counter}", "").strip()

                if qty > 0:
                    items.append({
                        "product":     product,
                        "quantity":    qty,
                        "width":       width,
                        "height":      height,
                        "unit_cost":   unit_cost,
                        "unit":        unit,
                        "description": description,
                    })
            except (Product.DoesNotExist, Unit.DoesNotExist, ValueError):
                pass  # skip invalid rows

            counter += 1
        return items

    def _render_with_context(self, request, quotation):
        """Re-render the form with validation errors."""
        existing_items = quotation.quotationitem_set.all()
        products       = Product.active_objects.all()
        units          = Unit.active_objects.all()
        context = {
            "quotation":       quotation,
            "products":        products,
            "units":           units,
            "locked_customer": quotation.customer,
            "existing_items":  existing_items,
        }
        return render(request, self.template, context)
class QuotationReportView(View):
    template = "pages/quotation/quotation_report.html"
    def get(self, request):
        quotations = Quotation.active_objects.all() 
        # Distinct approvers from quotations 
        approvers=(
                quotations
                .filter(approver__isnull=False)
                .order_by("approver__id")  
                .values("approver__id", "approver__first_name","approver__last_name").distinct()
            )
        # Distinct customers from quotations
        customers =(
                quotations
                .filter(customer__isnull=False)
                .order_by("customer__id")  
                .values("customer__id", "customer__name").distinct()   
            )
        context = {
            'quotations': quotations,
            'approvers': approvers,
            'customers': customers,
        }
        return render(request, self.template, context)
      

    def post(self, request):
        try:
            filters = {}
            approver_ids = request.POST.getlist("approver")
            status_list = request.POST.get("status")
            customer_ids = request.POST.getlist("customer")
            quotation_ids = request.POST.getlist("quotation")
            request_date_str = request.POST.getlist("request_date")
            if quotation_ids:
                quotation_ids = quotation_ids
                filters["id__in"] = quotation_ids
                
            if approver_ids:
                filters["approver__id__in"] = approver_ids
            if status_list:
                filters["approver_status"] = status_list
            if customer_ids:
                filters["customer__id__in"] = customer_ids

            if request_date_str:
                try:
                
                    if isinstance(request_date_str, list):
                        request_date_str = request_date_str[0]

                    request_date_str = request_date_str.strip()

                    if "to" in request_date_str:  # Date range case: "01-09-2025 to 06-09-2025"
                        start_str, end_str = [d.strip() for d in request_date_str.split("to")]
                        filters["request_date__date__range"] = (
                            datetime.strptime(start_str, "%d-%m-%Y").date(),
                            datetime.strptime(end_str, "%d-%m-%Y").date()
                        )
                    else:  # Single date case: "2025-09-06"
                        filters["request_date__date"] = datetime.strptime(request_date_str, "%Y-%m-%d").date()

                except ValueError:
                    return JsonResponse(
                        {"error": "Invalid date format. Use YYYY-MM-DD or DD-MM-YYYY to DD-MM-YYYY"},
                        status=400
                    )

            # Query database
            quotations_qs = (
                        Quotation.active_objects.filter(**filters).select_related("approver", "isosize").prefetch_related("customer", "items") )                         
            data = [
                    {
                        "id": q.id,
                        "invoice_number": q.invoice_number,
                        "price": float(q.total_cost),  # property, not callable
                        "approver": {
                            "id": q.approver.id,
                            "name": f"{q.approver.first_name} {q.approver.last_name}".strip()
                        } if q.approver else None,
                        "status": q.get_approver_status_display(),
                        "discount": float(q.discount) if q.discount is not None else None,
                        "request_date": q.request_date.strftime("%d-%m-%Y") if q.request_date else None,
                        "customer": {
                            "id": q.customer.id,
                            "name": f"{q.customer.name} "
                        } if q.customer else None,
                    }
                        for q in quotations_qs
            ]
            return JsonResponse({
                "message": "Quotations fetched successfully",
                "count": len(data),
                "data": data
            })

        except DatabaseError as db_err:
            return JsonResponse({"error": f"Database error: {str(db_err)}"}, status=500)
        
        except Exception as e:
            return JsonResponse({"error": f"Unexpected error: {str(e)}"}, status=500)