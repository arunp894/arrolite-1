from django.urls import path
from django.conf import settings
from django.conf.urls.static import static
from app.view.errors.custom_errors import custom_400, custom_403_csrf, custom_404, custom_500
from app.view.expenses.expenses_download import ExpenseExportView
from app.view.expenses.expenses_view import (
    ExpensesCreate,
    ExpensesDelete,
    ExpensesItemsCreate,
    ExpensesTypeDetail,
    ExpensesTypesCreate,
    ExpensesTypesDelete,
    ExpensesTypesUpdate,
    ExpensesUpdate,
    ExpensesViewList,
)
from app.view.home import HomePageView
from app.view.invoices.invoice_view import (
    InvoiceDetails,
    InvoiceEditView,
    InvoiceListView,
    InvoiceReportPdfView,
    InvoiceReportView,
    InvoiceRequestDetails,
    InvoiceRequestMarkPaidView,
    InvoiceRequestView,
    ProductReportInvoice,
    InvoiceDelete,
)
from app.view.iso_series.iso_view import ISOSizeDelete, ISOSizeEditView, ISOSizeListView
from app.view.permission.permission import (
    GroupUpdateView,
    GroupUserAddorUpdateView,
    PermissionAdd,
    PermissionSetting,
)
from app.view.product.product_view import (
    ProductDelete,
    ProductEditView,
    ProductListView,
    QuotationReportPdfView,
)
from app.view.quotation.quotation_view import (
    QuotationApprovalView,
    QuotationEditView,
    QuotationListView,
    QuotationReportView,
    QuotationRequestView,
    QuotationView,
    QuotationApprove,
)
from app.view.report_config.report_config import  InvoiceReportConfigView, QuotationReportConfigView
from app.view.sub_category.sub_category_view import (
    SubCategoryDelete,
    SubCategoryEditView,
    SubCategoryListView,
)
from app.view.category.category_view import (
    CategoryDelete,
    CategoryEditView,
    CategoryListView,
)
from app.view.customer.customer_view import (
    CustomUserRegister,
    CustomUserUpdate,
    CustomerList,
    CustomerRegister,
    CustomerUpdate,
    CustomuserList,
    Login,
    UserLogoutView,
    customerDelete,
)
from app.view.unit.unit_view import UnitDelete, UnitEditView, UnitListView

urlpatterns = [
    path("login/", Login.as_view(), name="login"),
    path("logout/", UserLogoutView.as_view(), name="logout"),
    path("", HomePageView.as_view(), name="home"),
    # User Path
    path("user_add/", CustomUserRegister.as_view(), name="user_add"),
    path("users/<int:pk>/edit/", CustomUserUpdate.as_view(), name="user_update"),
    path("user_list/", CustomuserList.as_view(), name="user_list"),
    # Category Path
    path("category-list/", CategoryListView.as_view(), name="category_list"),
    path("category-edit/<int:pk>/", CategoryEditView.as_view(), name="category_edit"),
    path("category-delete/<int:pk>/", CategoryDelete.as_view(), name="category_delete"),
    # Sub-Category Path
    path("sub-category-list/", SubCategoryListView.as_view(), name="sub_category_list"),
    path(
        "sub-category-edit/<int:pk>/",
        SubCategoryEditView.as_view(),
        name="sub_category_edit",
    ),
    path(
        "sub-category-delete/<int:pk>/",
        SubCategoryDelete.as_view(),
        name="sub_category_delete",
    ),
    # Product Path
    path("product-list/", ProductListView.as_view(), name="product_list"),
    path("product-edit/<int:pk>/", ProductEditView.as_view(), name="product_edit"),
    path("product-delete/<int:pk>/", ProductDelete.as_view(), name="product_delete"),
    # Quotation Path
    path("quotation-list/", QuotationListView.as_view(), name="quotation_list"),
    path(
        "quotation-awaiting/", QuotationApprovalView.as_view(), name="quotation_waiting"
    ),
    path(
        "quotation-request/", QuotationRequestView.as_view(), name="quotation_request"
    ),
     path(
        "quotation/<int:pk>/edit/", QuotationEditView.as_view(), name="quotation_edit"
    ),
    
    path(
        "quotation-report-pdf/", QuotationReportPdfView.as_view(), name="quotation_test"
    ),
    path("quotation-items/<int:pk>/", QuotationView.as_view(), name="quotation_items"),
    path(
        "quotation-approval/<int:pk>/",
        QuotationApprove.as_view(),
        name="quotation_approval",
    ),
    path("quotation-report/", QuotationReportView.as_view(), name="quotation_report"), 
    # Customer Path
    path("customer-list/", CustomerList.as_view(), name="customer_list"),
    path("customer-edit/<int:pk>", CustomerUpdate.as_view(), name="customer_edit"),
    path("customer-delete/<int:pk>", customerDelete.as_view(), name="customer_delete"),
    # Quotation Report Config
    path(
        "quotation-report-config/",
        QuotationReportConfigView.as_view(),
        name="quotation_report_config",
    ),
    # Invoice List
    path("invoice-list/", InvoiceListView.as_view(), name="quotation_invoice"),
    path("invoice-request/", InvoiceRequestView.as_view(), name="invoice_request"),
    path("invoice/<int:pk>/edit/", InvoiceEditView.as_view(), name="invoice_edit"), 
    path("invoice-delete/<int:pk>/", InvoiceDelete.as_view(), name="invoice_delete"), 
    path(
        "invoice-paid/",
        InvoiceRequestMarkPaidView.as_view(),
        name="invoice_paid_report",
    ),
    path(
        "invoice-report-config/",
        InvoiceReportConfigView.as_view(),
        name="invoice_report_config",
    ),
    path(
        "invoice-Request-Details/<int:pk>/",
        InvoiceRequestDetails.as_view(),
        name="invoice_paid_details",
    ),
    path("invoice-details/<int:pk>", InvoiceDetails.as_view(), name="invoice_details"),
    path("invoice-invoice_bill/", InvoiceReportPdfView.as_view(), name="invoice_bill"),
    path("Invoice-report/", InvoiceReportView.as_view(), name="invoice_report"),
    path(
        "Invoice-product-report/",
        ProductReportInvoice.as_view(),
        name="invoice_product_report",
    ),
    # Expenses Path
    path("expenses-list", ExpensesViewList.as_view(), name="expenses_list"),
    path(
        "expensestype-create", ExpensesTypesCreate.as_view(), name="expensestype_create"
    ),
    path(
        "expensestype-details",
        ExpensesTypeDetail.as_view(),
        name="expensestype_details",
    ),
    path(
        "expensestype-update/<int:pk>",
        ExpensesTypesUpdate.as_view(),
        name="expensestype_update",
    ),
    path(
        "expensestype-delete/<int:pk>",
        ExpensesTypesDelete.as_view(),
        name="expensestype_delete",
    ),
    path("expenses-create", ExpensesCreate.as_view(), name="expense_create"),
    path("expenses-update/<int:pk>", ExpensesUpdate.as_view(), name="expense_update"),
    path("expenses-update/<int:pk>", ExpensesDelete.as_view(), name="expense_delete"),
    path(
        "expenses-create-item",
        ExpensesItemsCreate.as_view(),
        name="expense_item_create",
    ),
    path("expenses/export/", ExpenseExportView.as_view(), name="expense_export"),
    # Permission Path
    path("permission-setting", PermissionSetting.as_view(), name="permission_setting"),
    path("permission-add", PermissionAdd.as_view(), name="permission_add"),
    path(
        "permission/<int:pk>/edit/", GroupUpdateView.as_view(), name="permission_update"
    ),
    path(
        "permission/<int:pk>/add-users/",
        GroupUserAddorUpdateView.as_view(),
        name="group_user_add",
    ),
    path("register-customer/", CustomerRegister.as_view(), name="register-customer"),
    # unit Path
    path("unit-list", UnitListView.as_view(), name="unit_list"),
    path("unit-edit/<int:pk>", UnitEditView.as_view(), name="unit_edit"),
    path("unit-delete/<int:pk>", UnitDelete.as_view(), name="unit_delete"),
    # ISO Path
    path("iso-list", ISOSizeListView.as_view(), name="iso_list"),
    path("iso-edit/<int:pk>", ISOSizeEditView.as_view(), name="iso_edit"),
    path("iso-delete/<int:pk>", ISOSizeDelete.as_view(), name="iso_delete"),
     
    # test errors
    path("test-400/", custom_400, name="test_400"),
    path("test-403/", custom_403_csrf, name="test_403"),
    path("test-404/", custom_404, name="test_404"),
    path("test-500/", custom_500, name="test_500"),
]
if settings.DEBUG:
    urlpatterns += static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
