from decimal import Decimal
from django.db import models
from django.forms import ValidationError
from app.models.base_model.basemodel import CustomBase
from app.models.category.category_model import Category
from app.models.customer_model.customer_model import CustomUser
from app.models.iso_series.iso_series_model import ISOSize
from app.models.product.path import product_image_upload_path
from app.models.product.product_model import Product
from app.models.unit.unit_model import Unit


class Invoice(CustomBase):
    STATUS_CHOICES = [
            ("draft", "Draft"),
            ("sent", "Sent to Customer"),
            ("pending", "Pending"),
            ("sent_to_manager", "Sent to Approver"),
            ("approved", "Approved"),
            ("rejected", "Rejected"),
            ("cancelled", "Cancelled"),
            ("expired", "Expired"),
            ("unpaid", "Unpaid"),
            ("pending_payment", "Pending Payment"),
            ("advance_paid", "Advance Paid"),   
            ("partially_paid", "Partially Paid"),
            ("paid", "Paid"),
            ("overdue", "Overdue"),
            ("refunded", "Refunded"),
            ("payment_failed", "Payment Failed"),
        ]
    customer = models.ForeignKey(
        "Customer",
        related_name="invoice_customers",
         on_delete=models.CASCADE,
        null=True,
        blank=True,
    )
    approver = models.ForeignKey(
        "CustomUser",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name='invoice_approvers'
    )
    manager = models.ForeignKey(
        "CustomUser",
        on_delete=models.CASCADE,
        blank=True,
        null=True,
        related_name='invoice_manager'
    )
    request_date = models.DateTimeField(null=True, blank=True)
    invoice_number = models.CharField(max_length=20, unique=True)
    description = models.TextField(null=True, blank=True)
    approver_status = models.CharField(
        max_length=30,
        choices=STATUS_CHOICES,
        default="pending"
    )
    discount = models.DecimalField(
        max_digits=6,
        decimal_places=2,
        default=0.00,
        null=True,
        blank=True,
        help_text="Discount amount or percentage to apply"
    )
    is_percentage = models.BooleanField(
        default=False,
    help_text="If true, discount_value is a percentage instead of a fixed amount"
    ) 
    allow_percentage_discount = models.BooleanField(
        default=False,
        help_text="If true, discount_value is a percentage instead of a fixed amount allowed"
    )
    isosize = models.ForeignKey("ISOSize", on_delete=models.SET_NULL, null=True, blank=True)
    advance_amount = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    amount_paid = models.DecimalField(max_digits=10, decimal_places=2, default=0)
    class Meta:
        verbose_name = "Invoice"
        verbose_name_plural = "Invoices"
        permissions = [
            ("can_approve_invoice", "Can approve Invoice"),
            ("can_manage_invoice","Can manage Invoice"),
            ("can_report_invoice","Can Report Invoice"),
            ("can_manager_access", "Manager: Can Access Invoice"),  
            ("can_modify_invoice", "Can Modify Invoice"),
            ("can_delete_invoice", "Can Delete Invoice"),

        ]
        ordering = ["-created_at"]
    def __str__(self):
        return f"{self.invoice_number}"


    @property
    def total_cost(self):
        """
        Sum of all item costs (before discount).
        IMPORTANT: multiply unit_cost * quantity (this was missing before).
        """
        return sum(
            (item.unit_cost or Decimal("0.00"))  
            for item in self.invoiceitems.all()
        ) or Decimal("0.00")

    @property
    def discount_amount(self):
        """
        Fixed discount always applies.
        Percentage only applies when allow_percentage_discount AND is_percentage are both True.
        """
        total    = self.total_cost or Decimal("0.00")
        discount = Decimal(str(self.discount or 0))
    
        if discount <= 0:
            return Decimal("0.00")
    
        if self.allow_percentage_discount and self.is_percentage:
            return (discount / Decimal("100")) * total
    
        return discount  # flat always
    
    
    @property
    def payable_total(self):
        """Total after discount."""
        total = self.total_cost or Decimal("0.00")
        return total - (self.discount_amount or Decimal("0.00"))
    
    
    @property
    def total_paid(self):
        return (self.advance_amount or Decimal("0.00")) + \
            (self.amount_paid    or Decimal("0.00"))
    
    
    @property
    def balance_due(self):
        return (self.payable_total or Decimal("0.00")) - self.total_paid
        
            
class InvoiceItem(CustomBase):  # Singular name is conventional
    invoice = models.ForeignKey(
        "Invoice", on_delete=models.CASCADE, related_name='invoiceitems'
    )
    product = models.ForeignKey(  # changed from ManyToManyField to ForeignKey
        "Product",
        on_delete=models.CASCADE,
        related_name="invoice_items"
    )
    quantity = models.PositiveIntegerField()
    unit_cost = models.DecimalField(max_digits=20, decimal_places=2, null=True, blank=True)
    unit = models.ForeignKey("Unit", on_delete=models.SET_NULL, null=True, blank=True)
    width = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    height = models.DecimalField(max_digits=10, decimal_places=2, null=True, blank=True)
    # auto_derivation = models.BooleanField(default=True,null=True ,blank=True,help_text="If true, total price is calculated automatically based on quantity and unit cost. If false, user can enter a custom total price.")
    description = models.TextField(null=True, blank=True)
     
    class Meta:
            ordering = ["-created_at"]

    def __str__(self):
        return f"{self.product.name}-status={self.is_deleted}"
   
def default_report_config():
    return {
        "show_design_note": True,
        "show_deposit_note": True,
        "design_note": "DESIGN PROVIDED BY YOU",
        "deposit_note": "50% deposit required",
        "show_footer": True
    }

 

class QuotationReportGenerator(CustomBase):
    is_tagged = models.BooleanField(default=False)

    # ✅ default config applied automatically
    label = models.JSONField(default=default_report_config, blank=True, null=True)

    def save(self, *args, **kwargs): 
        if not self.pk and QuotationReportGenerator.objects.exists():
            raise ValidationError("Only one config allowed")

        # ✅ merge default + user data
        default = default_report_config()
        if self.label:
            default.update(self.label)

        self.label = default
        super().save(*args, **kwargs)
        
class InvoiceReportGenerator(CustomBase):
    is_tagged = models.BooleanField(default=False)

    # ✅ default config applied automatically
    label = models.JSONField(default=default_report_config, blank=True, null=True)

    def save(self, *args, **kwargs): 
        if not self.pk and InvoiceReportGenerator.objects.exists():
            raise ValidationError("Only one config allowed")

        # ✅ merge default + user data
        default = default_report_config()
        if self.label:
            default.update(self.label)

        self.label = default
        super().save(*args, **kwargs)
    
     
     