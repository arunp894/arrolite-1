"""
URL configuration for arrolite project.

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/5.2/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import include, path
 

urlpatterns = [
    path('admin/', admin.site.urls),
    path("", include("app.urls")),
]
handler400 = 'app.view.errors.custom_errors.custom_400'
handler403 = 'app.view.errors.custom_errors.custom_403_csrf'
handler404 = 'app.view.errors.custom_errors.custom_404'
handler500 = 'app.view.errors.custom_errors.custom_500'
 